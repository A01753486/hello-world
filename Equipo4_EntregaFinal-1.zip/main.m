%Equipo 4
function main()
    clear;clc;clf;close all;
    m=1000;
    d=20;
    df=10;
    ang=55;
    h=2;
    r1=5;
    de=3;%
    th=ang*2*pi/360;
    r0=h/(1-cos(th)); r2=2*r1/3; r3=2*r2/3; C=r0*th;
    hcol1=r3; hcol2=hcol1/2;
    ttot = 0;
    deltat = 0.01;
    posicion = 0;
    velocidad = 0;
    coefn=0.01;
    coeff=0.7;
    coefp=0.3;
    g=9.81;
    ei=m*g*(h+d*sin(th));
    
    [lim1,lim2,lim3,lim4,lim5,lim6,lim7,lim8,lim9,lim10,lim11,lim12,x,y]=trayectoria(d,th,h,r0,r1,r2,r3,C,de,hcol1,hcol2,df);
    [ts,act,acc,actot,vels,ecs,eps]=movimiento(lim1,lim2,lim3,lim4,lim5,lim6,lim7,lim8,lim9,lim10,lim11,lim12,x,y,ttot,deltat,posicion,velocidad,coefn,coeff,coefp,th,g,r0,r1,r2,r3,hcol1,hcol2,m,ei,d,h);
    
    figure(2)
    plot(ts,acc)
    grid
    xlim([0,max(ts)]);
    ylim([min(acc)-3,max(acc)+5]);
    line([0 max(ts)],[0 0],'color','k')
    line([0 max(ts)],[2*g 2*g],'color','r')
    line([0 max(ts)],[-2*g -2*g],'color','r')
    xlabel('tiempo')
    ylabel('aceleración')
    title('Aceleración centrípeta del carrito en las vueltas')
    
    figure(3)
    plot(ts,act)
    grid
    xlim([0,max(ts)]);
    ylim([min(act)-3,max(act)+5]);
    line([0 max(ts)],[0 0],'color','k')
    xlabel('tiempo')
    ylabel('aceleración')
    title('Aceleración tangencial del carrito')
    
    figure(4)
    plot(ts,actot)
    grid
    xlim([0,max(ts)]);
    ylim([min(actot)-10,max(actot)+10]);
    line([0 max(ts)],[0 0],'color','k')
    xlabel('tiempo')
    ylabel('aceleración')
    title('Aceleración total del carrito')
    
    figure(5)
    plot(ts,vels)
    grid
    xlim([0,max(ts)]);
    ylim([min(vels)-3,max(vels)+3]);
    line([0 max(ts)],[0 0],'color','k')
    xlabel('tiempo')
    ylabel('velocidad')
    title('Velocidad')
    
    figure(6)
    plot(ts,ecs)
    hold on
    plot(ts,eps,"Color","red")
    grid
    xlim([0,max(ts)]);
    ylim([min(eps),max(eps)]);
    line([0 max(ts)],[0 0],'color','k')
    xlabel('tiempo')
    ylabel('energía')
    title('Energía cinética vs potencial')
end