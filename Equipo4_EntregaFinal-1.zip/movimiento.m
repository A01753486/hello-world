%Equipo 4
function [tiempos,aceleracionestan,aceleracionescen,aceleracionestot,velocidades,enercins,enerpots]=movimiento(l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,enx,eny,ttot,deltat,posicion,velocidad,coefn,coeff,coefp,th,g,r0,r1,r2,r3,hcol1,hcol2,m,ei,d,h)
    p=animatedline('Marker','.','Color','red','Markersize',10,'MarkerFaceColor','red');
    sec_annot=annotation('textbox',[0.13,0.85,0.1,0.1],"String","");
    dat_annot=annotation('textbox',[0.6,0.88,0.1,0.1],"String","");
    pel_annot=annotation('textbox',[0.13,0.8,0.1,0.05],"String","",'FitBoxToText','on');
    py1=-sin((l9-l9)/(hcol1/2));py2=-sin((l10-l10)/(hcol2/2));
    vi=0;
    tiempos=[];aceleracionestan=[];aceleracionescen=[];aceleracionestot=[];velocidades=[];enercins=[];enerpots=[];
    while 1
        clearpoints(p);
        posicion=posicion+velocidad*deltat;
        ttot=ttot+deltat;
        addpoints(p,double(enx(posicion)),double(eny(posicion)));
        drawnow;
        if posicion <= l1
            ann=0;rr=0;
            dv=-g*(coefn*cos(th)-sin(th))*deltat;
            dvi=g*(sin(th))*deltat;
            alt=h+d*sin(th)-posicion*sin(th);
            txtsec=sprintf("Sección del circuito: Rampa inicial (1)");
        elseif posicion <= l2
            rr=0;
            ann=ann+(velocidad*deltat)/r0;
            dv=-(coefn*((velocidad^2)/r0+g*cos(ann))+g*sin(ann))*deltat;
            dvi=-(g*sin(ann))*deltat;
            alt=h+r0*(cos(th)-cos(th-(posicion-d)/r0));
            txtsec=sprintf("Sección del circuito: Curva inicial (2)");
        elseif posicion <= l3
            ann=0;rr=0;
            dv=-coefp*g*deltat;
            dvi=0;
            alt=0;
            txtsec=sprintf("Sección del circuito: Primer recta (3)");
        elseif posicion <= l4
            rr=r1;
            ann=ann+(velocidad*deltat)/r1;
            dv=-(coefn*((velocidad^2)/r1+g*cos(ann))+g*sin(ann))*deltat;
            dvi=-(g*sin(ann))*deltat;
            alt=r1*(1-cos((posicion-l3)/r1));
            txtsec=sprintf("Sección del circuito: Primer vuelta (4)");
        elseif posicion <= l5
            ann=0;rr=0;
            dv=-coefp*g*deltat;
            dvi=0;
            alt=0;
            txtsec=sprintf("Sección del circuito: Segunda recta (5)");
        elseif posicion <= l6
            rr=r2;
            ann=ann+(velocidad*deltat)/r2;
            dv=-(coefn*((velocidad^2)/r2+g*cos(ann))+g*sin(ann))*deltat;
            dvi=-(g*sin(ann))*deltat;
            alt=r2*(1-cos((posicion-l5)/r2));
            txtsec=sprintf("Sección del circuito: Segunda vuelta (6)");
        elseif posicion <= l7
            ann=0;rr=0;
            dv=-coefp*g*deltat;
            dvi=0;
            alt=0;
            txtsec=sprintf("Sección del circuito: Tercer recta (7)");
        elseif posicion <= l8
            rr=r0;
            ann=ann+(velocidad*deltat)/r3;
            dv=-(coefn*((velocidad^2)/r3+g*cos(ann))+g*sin(ann))*deltat;
            dvi=-(g*sin(ann))*deltat;
            alt=r3*(1-cos((posicion-l7)/r3));
            txtsec=sprintf("Sección del circuito: Tercer vuelta (8)");
        elseif posicion <= l9
            ann=0;rr=0;
            dv=-coefp*g*deltat;
            dvi=0;
            alt=0;
            txtsec=sprintf("Sección del circuito: Cuarta recta (9)");
        elseif posicion <= l10
            dv=(-coefn/(sqrt(1+(py1)^2))-py1)*g*deltat;
            dvi=(-py1)*g*deltat;
            py1=-sin((l9-posicion)/(hcol1/2));
            alt=(hcol1/2)*(1-cos((posicion-l9)/(hcol1/2)));
            txtsec=sprintf("Secció  n del circuito: Primer colina (10)");
        elseif posicion <= l11
            dv=(-coefn/(sqrt(1+(py2)^2))-py2)*g*deltat;
            dvi=-py2*g*deltat;
            py2=-sin((l10-posicion)/(hcol2/2));
            alt=(hcol2/2)*(1-cos((posicion-l10)/(hcol2/2)));
            txtsec=sprintf("Sección del circuito: Segunda colina (11)");
        elseif posicion <= l12
            rr=0;
            dv=-coeff*g*deltat;
            dvi=0;
            alt=0;
            txtsec=sprintf("Sección del circuito: Recta final (12)");
            if velocidad <= 0
                break
            end
        else
            break
        end
        velocidad=velocidad+dv;vi=vi+dvi;
        switch rr
            case 0
                aceleracioncen=0;
            otherwise
                aceleracioncen=(velocidad^2)/rr;
        end
        aceleraciontan=dv/deltat;
        aceleraciontot=sqrt((aceleraciontan^2)+(aceleracioncen^2));
        dfv=abs(vi)-abs(velocidad);
        eper=0.5*m*dfv^2;
        enercin=0.5*m*velocidad^2;enerpot=m*g*alt;
        tiempos=[tiempos ttot];aceleracionestan=[aceleracionestan aceleraciontan];aceleracionescen=[aceleracionescen aceleracioncen];aceleracionestot=[aceleracionestot aceleraciontot];velocidades=[velocidades velocidad];enercins=[enercins enercin];enerpots=[enerpots enerpot];
        txtdat=sprintf("Energía inicial: %.2f J\nPosición: Ha recorrido %.2f metros\nVelocidad: %.2f m/s\nTiempo transcurrido: %.2f\nAceleración tangencial: %.2f m/s2\nAceleración centrípeta en el círculo: %.2f m/s2\nAceleración total: %.2f m/s2\nEnergía perdida por fricción: %.2f J\nEnergía cinética: %.2f J\nEnergía potencial: %.2f J",ei,posicion,velocidad,ttot,aceleraciontan,aceleracioncen,aceleraciontot,eper,enercin,enerpot);
        set(sec_annot,"String",txtsec);
        set(dat_annot,"String",txtdat);
        if abs(aceleracioncen) >= 2*g
            txtpel=sprintf("Peligro: Se ha se está experimentando una aceleración de %.2f g",aceleracioncen/g);
            set(pel_annot,"String",txtpel);
        else
            txtpel=sprintf("No hay peligro (aceleración centrípeta menor que 2g)");
            set(pel_annot,"String",txtpel);
        end
    end
    hold off
end